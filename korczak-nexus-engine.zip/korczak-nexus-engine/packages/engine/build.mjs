// Bundles the engine into a single ESM file and emits type declarations with tsc.
import { spawnSync } from "node:child_process";
import { rmSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { loadEsbuild } from "../../scripts/esbuild-loader.mjs";

const here = dirname(fileURLToPath(import.meta.url));
rmSync(resolve(here, "dist"), { recursive: true, force: true });
const esbuild = loadEsbuild();
await esbuild.build({
  entryPoints: [resolve(here, "src/index.ts")],
  outfile: resolve(here, "dist/index.js"),
  bundle: true, format: "esm", platform: "neutral", target: "es2022", sourcemap: true, legalComments: "none",
});
const tscBin = resolve(here, "../../node_modules/typescript/bin/tsc");
const r = spawnSync(process.execPath, [tscBin, "-p", resolve(here, "tsconfig.build.json"), "--emitDeclarationOnly", "--declaration"], { stdio: "inherit", cwd: here });
if (r.status !== 0) process.exit(r.status ?? 1);
console.log("engine build ok -> packages/engine/dist");
