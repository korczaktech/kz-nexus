// Seeded property-style tests (Section 16.7). Every failure prints its seed.
import { describe, expect, it } from "vitest";
import {
  addTableRow,
  applyMark,
  createEditor,
  createFixedClock,
  createIdGenerator,
  createSeededRandomForTests,
  deleteText,
  insertList,
  insertTable,
  insertText,
  mergeBlockWithPrevious,
  normalizeDocument,
  openNsx,
  saveNsx,
  setAlign,
  setHeadingLevel,
  splitBlock,
  validateDocument,
  type Command,
  type Editor,
} from "../src/index";

const WORDS = ["olá", "açaí", "😀", "e\u0301", "mundo", "x", "Nexus", "ção", " ", "\u00a0"];

function randomCommand(editor: Editor, rand: () => number): Command | undefined {
  const blocks = editor.getDocument().content.filter((b) => b.type === "paragraph" || b.type === "heading");
  if (blocks.length === 0) return undefined;
  const block = blocks[Math.floor(rand() * blocks.length)];
  if (!block || (block.type !== "paragraph" && block.type !== "heading")) return undefined;
  const length = block.children.reduce((n, r) => n + r.text.length, 0);
  const at = Math.floor(rand() * (length + 1));
  const end = Math.min(length, at + Math.floor(rand() * 5));
  switch (Math.floor(rand() * 10)) {
    case 0:
    case 1:
    case 2:
      return insertText({ blockId: block.id, offset: at, text: WORDS[Math.floor(rand() * WORDS.length)] ?? "a" });
    case 3:
      return deleteText({ blockId: block.id, start: at, end });
    case 4:
      return applyMark({ blockId: block.id, start: at, end, mark: rand() < 0.5 ? { type: "bold" } : { type: "color", value: "#aa00ff" } });
    case 5:
      return splitBlock({ blockId: block.id, offset: at });
    case 6:
      return mergeBlockWithPrevious({ blockId: block.id });
    case 7:
      return setHeadingLevel({ blockId: block.id, level: (1 + Math.floor(rand() * 3)) as 1 | 2 | 3 });
    case 8:
      return rand() < 0.5 ? insertList({ afterBlockId: block.id, ordered: rand() < 0.5 }) : setAlign({ blockId: block.id, align: "center" });
    default:
      return rand() < 0.5 ? insertTable({ afterBlockId: block.id, rows: 2, columns: 2 }) : insertText({ blockId: block.id, offset: 0, text: "." });
  }
}

function newEditor(seed: number) {
  const { now } = createFixedClock(0);
  return createEditor({ idGenerator: createIdGenerator("n", seed), clock: now, historyOptions: { typingGroupWindowMs: 0, maxEntries: 10_000 } });
}

const SEEDS = Array.from({ length: 25 }, (_, i) => 1000 + i);

describe("properties (seeded)", () => {
  for (const seed of SEEDS) {
    it(`seed ${seed}: invariants hold across 60 random operations`, () => {
      const rand = createSeededRandomForTests(seed);
      const editor = newEditor(seed);
      const history: string[] = [JSON.stringify(editor.getDocument())];
      for (let step = 0; step < 60; step++) {
        const command = randomCommand(editor, rand);
        if (!command) break;
        const before = JSON.stringify(editor.getDocument());
        const result = editor.exec([command]);
        if (!result.ok) {
          // A rejected transaction must not modify the committed state.
          expect(JSON.stringify(editor.getDocument())).toBe(before);
          continue;
        }
        history.push(JSON.stringify(editor.getDocument()));
        expect(validateDocument(editor.getDocument()).ok).toBe(true);
      }

      // validate / serialize must not modify the document.
      const snapshot = JSON.stringify(editor.getDocument());
      editor.validate();
      saveNsx(editor.getDocument());
      expect(JSON.stringify(editor.getDocument())).toBe(snapshot);

      // normalize twice == normalize once (idempotence).
      const once = normalizeDocument(editor.getDocument(), createIdGenerator("z", seed));
      const twice = normalizeDocument(once, createIdGenerator("y", seed));
      expect(twice).toEqual(once);

      // round-trip preserves semantics for the normalized document.
      const saved = saveNsx(once);
      expect(saved.ok).toBe(true);
      if (saved.ok) {
        const reopened = openNsx(saved.value);
        expect(reopened.ok).toBe(true);
        if (reopened.ok) expect(reopened.value).toEqual(once);
      }

      // undo walks back through every committed state; redo walks forward again.
      for (let i = history.length - 1; i > 0; i--) {
        expect(JSON.stringify(editor.getDocument())).toBe(history[i]);
        expect(editor.undo()).toBe(true);
      }
      expect(JSON.stringify(editor.getDocument())).toBe(history[0]);
      for (let i = 1; i < history.length; i++) {
        expect(editor.redo()).toBe(true);
        expect(JSON.stringify(editor.getDocument())).toBe(history[i]);
      }
    });
  }

  it("addTableRow on a missing table is rejected without side effects", () => {
    const editor = newEditor(7);
    const before = JSON.stringify(editor.getDocument());
    expect(editor.exec([addTableRow({ tableId: "n_nope" })]).ok).toBe(false);
    expect(JSON.stringify(editor.getDocument())).toBe(before);
  });
});
