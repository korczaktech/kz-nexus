// Imports ONLY through the public entry point (Section 11.2).
import { describe, expect, it } from "vitest";
import {
  applyMark,
  createEditor,
  createFixedClock,
  createIdGenerator,
  exportPlainText,
  getPlainText,
  insertList,
  insertTable,
  insertText,
  openNsx,
  saveNsx,
  setHeadingLevel,
  splitBlock,
  type Block,
} from "../src/index";

function newEditor() {
  const { now } = createFixedClock(1_000);
  return createEditor({ idGenerator: createIdGenerator("n", 42), clock: now, historyOptions: { typingGroupWindowMs: 0 } });
}

function firstId(blocks: readonly Block[]): string {
  const b = blocks[0];
  if (!b) throw new Error("empty document");
  return b.id;
}

describe("public API (headless)", () => {
  it("edits, formats, undoes, redoes and round-trips through .nsx without any DOM", () => {
    const editor = newEditor();
    const id = firstId(editor.getDocument().content);
    expect(editor.exec([insertText({ blockId: id, offset: 0, text: "Olá, açaí 😀 café" })]).ok).toBe(true);
    expect(editor.exec([applyMark({ blockId: id, start: 0, end: 3, mark: { type: "bold" } })]).ok).toBe(true);
    expect(editor.exec([splitBlock({ blockId: id, offset: 3 })]).ok).toBe(true);
    const doc = editor.getDocument();
    expect(doc.content).toHaveLength(2);
    const second = doc.content[1];
    if (!second) throw new Error("missing second block");
    expect(editor.exec([setHeadingLevel({ blockId: second.id, level: 2 })]).ok).toBe(true);
    expect(editor.exec([insertList({ afterBlockId: second.id, ordered: true })]).ok).toBe(true);
    expect(editor.exec([insertTable({ afterBlockId: second.id, rows: 2, columns: 3 })]).ok).toBe(true);
    expect(editor.validate().ok).toBe(true);

    const saved = saveNsx(editor.getDocument());
    expect(saved.ok).toBe(true);
    if (!saved.ok) return;
    const reopened = openNsx(saved.value);
    expect(reopened.ok).toBe(true);
    if (!reopened.ok) return;
    expect(reopened.value).toEqual(editor.getDocument());
    expect(exportPlainText(reopened.value)).toBe(exportPlainText(editor.getDocument()));

    const snapshot = JSON.stringify(editor.getDocument());
    while (editor.canUndo()) editor.undo();
    expect(getPlainText(editor.getDocument().content[0] as never)).toBe("");
    while (editor.canRedo()) editor.redo();
    expect(JSON.stringify(editor.getDocument())).toBe(snapshot);
  });

  it("rejects a bad transaction atomically and leaves the committed document untouched", () => {
    const editor = newEditor();
    const id = firstId(editor.getDocument().content);
    const before = JSON.stringify(editor.getDocument());
    const result = editor.exec([
      insertText({ blockId: id, offset: 0, text: "parcial" }),
      insertText({ blockId: "n_missing", offset: 0, text: "x" }),
    ]);
    expect(result.ok).toBe(false);
    expect(JSON.stringify(editor.getDocument())).toBe(before);
    expect(editor.canUndo()).toBe(false);
  });

  it("failed open does not replace the current document", () => {
    const editor = newEditor();
    const id = firstId(editor.getDocument().content);
    editor.exec([insertText({ blockId: id, offset: 0, text: "mantido" })]);
    const before = JSON.stringify(editor.getDocument());
    const result = editor.open("{ not json");
    expect(result.ok).toBe(false);
    expect(JSON.stringify(editor.getDocument())).toBe(before);
  });

  it("does not let hosts mutate engine-owned state", () => {
    const editor = newEditor();
    const doc = editor.getDocument();
    expect(() => {
      (doc.content as Block[]).push(doc.content[0] as Block);
    }).toThrow();
  });
});
