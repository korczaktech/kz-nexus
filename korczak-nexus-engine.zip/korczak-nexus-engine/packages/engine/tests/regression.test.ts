// Regression tests for defects found by the browser E2E run.
import { describe, expect, it } from "vitest";
import { applyMark, createEditor, createFixedClock, createIdGenerator, insertText, openNsx, removeMark, saveNsx, splitBlock } from "../src/index";

function newEditor() {
  const { now } = createFixedClock(0);
  return createEditor({ idGenerator: createIdGenerator("n", 3), clock: now, historyOptions: { typingGroupWindowMs: 0 } });
}

describe("run coalescing (regression: one run per keystroke)", () => {
  it("typing character by character keeps a single text run", () => {
    const e = newEditor();
    const id = e.getDocument().content[0]!.id;
    const word = "Olá mundo";
    for (let i = 0; i < word.length; i++) expect(e.exec([insertText({ blockId: id, offset: i, text: word[i]! })]).ok).toBe(true);
    const block = e.getDocument().content[0]!;
    expect(block.type === "paragraph" ? block.children : []).toHaveLength(1);
  });

  it("applying then removing a mark over the whole text returns to a single run", () => {
    const e = newEditor();
    const id = e.getDocument().content[0]!.id;
    e.exec([insertText({ blockId: id, offset: 0, text: "abcdef" })]);
    e.exec([applyMark({ blockId: id, start: 2, end: 4, mark: { type: "bold" } })]);
    let block = e.getDocument().content[0]!;
    expect(block.type === "paragraph" ? block.children : []).toHaveLength(3);
    e.exec([removeMark({ blockId: id, start: 2, end: 4, markType: "bold" })]);
    block = e.getDocument().content[0]!;
    expect(block.type === "paragraph" ? block.children : []).toHaveLength(1);
  });

  it("a freshly edited document is identical after save + open (no hidden normalization drift)", () => {
    const e = newEditor();
    const id = e.getDocument().content[0]!.id;
    for (const ch of "Olá mundo açaí") e.exec([insertText({ blockId: id, offset: (e.getDocument().content[0] as { children: { text: string }[] }).children.map((r) => r.text).join("").length, text: ch })]);
    e.exec([applyMark({ blockId: id, start: 0, end: 14, mark: { type: "bold" } })]);
    e.exec([splitBlock({ blockId: id, offset: 3 })]);
    const saved = saveNsx(e.getDocument());
    expect(saved.ok).toBe(true);
    if (!saved.ok) return;
    const opened = openNsx(saved.value);
    expect(opened.ok).toBe(true);
    if (opened.ok) expect(opened.value).toEqual(e.getDocument());
  });
});
