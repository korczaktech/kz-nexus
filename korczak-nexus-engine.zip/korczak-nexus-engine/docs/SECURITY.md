# Segurança

Arquivos e entradas externas são não confiáveis. Implementado: limites configuráveis (tamanho, nós, profundidade, run, recursos, metadados), validação do envelope e do esquema, rejeição de tipos desconhecidos, sem `eval`/`new Function`, erros estruturados, sem log de conteúdo, falha de abertura não altera a sessão.
Riscos/limitações conhecidos: sem assinatura/criptografia (adulteração não detectada); recursos aceitam `image/png|jpeg|gif|webp|svg+xml` validados por tipo declarado e tamanho, **sem inspeção de assinatura binária (magic bytes)** e **sem sanitização de SVG** (hosts devem exibir SVG só via `<img>`/data URI, nunca inline); JSON.parse não tem limite de CPU além do tamanho máximo; sanitização de HTML importado **não existe** porque o importador HTML não foi implementado.
O preview exibe imagens via `data:` em `<img>` (scripts em SVG não executam nesse contexto); o seletor do preview só oferece PNG/JPEG/GIF/WebP.
